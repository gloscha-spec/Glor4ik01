import Foundation
import AVFoundation
import Accelerate

struct VoiceMetrics {
    let duration: Double
    let rmsDBFS: Double
    let silenceFraction: Double
    let peakDBFS: Double
}

enum VoiceAnalyzer {
    static func analyze(url: URL) async throws -> VoiceMetrics {
        try await Task.detached(priority: .userInitiated) {
            let file = try AVAudioFile(forReading: url)
            guard let buffer = AVAudioPCMBuffer(pcmFormat: file.processingFormat, frameCapacity: 4096) else {
                throw NSError(domain: "VoiceCheck", code: 2, userInfo: [NSLocalizedDescriptionKey: "Audioformat nicht lesbar."])
            }
            var sumSquares = 0.0
            var totalSamples = 0
            var silentFrames = 0
            var frames = 0
            var maxAmplitude = 0.0
            while true {
                try file.read(into: buffer, frameCount: 4096)
                let count = Int(buffer.frameLength)
                if count == 0 { break }
                guard let channels = buffer.floatChannelData else { continue }
                let samples = channels[0]
                var frameEnergy = 0.0
                for i in 0..<count {
                    let x = Double(samples[i])
                    let energy = x * x
                    sumSquares += energy
                    frameEnergy += energy
                    maxAmplitude = max(maxAmplitude, abs(x))
                }
                let frameRMS = sqrt(frameEnergy / Double(count))
                // Simple amplitude-based silence estimate; background noise affects this.
                if frameRMS < 0.01 { silentFrames += count }
                totalSamples += count
                frames += 1
            }
            guard totalSamples > 0 else {
                throw NSError(domain: "VoiceCheck", code: 3, userInfo: [NSLocalizedDescriptionKey: "Die Aufnahme ist leer."])
            }
            let rms = sqrt(sumSquares / Double(totalSamples))
            return VoiceMetrics(
                duration: Double(totalSamples) / file.processingFormat.sampleRate,
                rmsDBFS: 20 * log10(max(rms, 1e-10)),
                silenceFraction: Double(silentFrames) / Double(totalSamples),
                peakDBFS: 20 * log10(max(maxAmplitude, 1e-10))
            )
        }.value
    }
}
