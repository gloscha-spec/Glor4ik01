import SwiftUI

@main
struct VoiceCheckAIApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}
