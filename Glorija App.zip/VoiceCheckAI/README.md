# VoiceCheck AI — iOS SwiftUI MVP

Eine native iPhone-App zur lokalen Aufnahme und einfachen akustischen Auswertung. Kein Lügendetektor.

## In Xcode starten

1. Xcode (aktuelle Version) auf einem Mac öffnen und **File > New > Project > iOS > App** wählen.
2. Product Name: `VoiceCheckAI`; Interface: **SwiftUI**; Language: **Swift**; Deployment Target: **iOS 17 oder neuer**.
3. Die vier `.swift`-Dateien aus diesem Ordner in das Projekt ziehen und die von Xcode angelegte `VoiceCheckAIApp.swift` bzw. `ContentView.swift` ersetzen, statt doppelt einzubinden.
4. In den Target-Einstellungen unter **Info > Custom iOS Target Properties** den Eintrag **Privacy - Microphone Usage Description** (`NSMicrophoneUsageDescription`) hinzufügen, z. B. `VoiceCheck AI benötigt das Mikrofon, um deine Stimme lokal aufzunehmen.`
5. Ein iPhone als Ziel auswählen, Signing Team einstellen und **Run** drücken. Ein Mac mit Xcode ist für diesen nativen Build nötig.

## Was die App misst

- Dauer der Aufnahme
- digitalen durchschnittlichen RMS-Pegel (dBFS)
- digitalen Spitzenpegel (dBFS)
- grob geschätzten Anteil leiser Audioabschnitte (Schwelle: RMS < 0,01 pro Audioblock)

Die Schätzung ist abhängig von Umgebung, Mikrofon und Aufnahmepegel. Keine Diagnose von Nervosität, Emotionen oder Wahrheit. Dateien werden temporär lokal gespeichert und derzeit nicht über eine Benutzeroberfläche verwaltet. Für eine veröffentlichungsreife App fehlen u. a. dauerhafte Aufnahmenverwaltung, Löschfunktion, Tests und Datenschutztexte.
