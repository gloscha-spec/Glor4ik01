import Foundation
import AVFoundation

@MainActor
final class AudioRecorder: NSObject, ObservableObject, AVAudioRecorderDelegate {
    @Published var isRecording = false
    @Published var permissionDenied = false
    @Published var lastURL: URL?
    @Published var duration: TimeInterval = 0
    @Published var errorMessage: String?
    private var recorder: AVAudioRecorder?
    private var timer: Timer?

    func start() async {
        let granted = await withCheckedContinuation { continuation in
            AVAudioApplication.requestRecordPermission { allowed in
                continuation.resume(returning: allowed)
            }
        }
        guard granted else { permissionDenied = true; return }
        do {
            try AVAudioSession.sharedInstance().setCategory(.playAndRecord, mode: .default, options: [.defaultToSpeaker])
            try AVAudioSession.sharedInstance().setActive(true)
            let url = FileManager.default.temporaryDirectory.appendingPathComponent("voicecheck-\(UUID().uuidString).m4a")
            let settings: [String: Any] = [
                AVFormatIDKey: Int(kAudioFormatMPEG4AAC),
                AVSampleRateKey: 44100,
                AVNumberOfChannelsKey: 1,
                AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue
            ]
            let newRecorder = try AVAudioRecorder(url: url, settings: settings)
            newRecorder.delegate = self
            newRecorder.isMeteringEnabled = true
            guard newRecorder.record() else { throw NSError(domain: "VoiceCheck", code: 1, userInfo: [NSLocalizedDescriptionKey: "Aufnahme konnte nicht gestartet werden."]) }
            recorder = newRecorder
            lastURL = nil
            duration = 0
            isRecording = true
            timer?.invalidate()
            timer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { [weak self] _ in
                Task { @MainActor in self?.duration = self?.recorder?.currentTime ?? 0 }
            }
        } catch { errorMessage = error.localizedDescription }
    }

    func stop() {
        guard let recorder else { return }
        let url = recorder.url
        recorder.stop()
        lastURL = url
        isRecording = false
        timer?.invalidate()
        timer = nil
        self.recorder = nil
        try? AVAudioSession.sharedInstance().setActive(false)
    }
}
