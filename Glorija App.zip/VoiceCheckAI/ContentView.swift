import SwiftUI
import AVFoundation

struct ContentView: View {
    @StateObject private var recorder = AudioRecorder()
    @State private var metrics: VoiceMetrics?
    @State private var analyzing = false
    @State private var analysisError: String?
    @State private var player: AVAudioPlayer?

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 22) {
                    Image(systemName: "waveform.circle.fill")
                        .font(.system(size: 86))
                        .foregroundStyle(.teal)
                    Text("Deine Stimme verstehen")
                        .font(.title2.bold())
                    Text("Nimm deine Stimme auf und sieh dir messbare akustische Merkmale an. Alle Aufnahmen bleiben auf deinem Gerät.")
                        .multilineTextAlignment(.center)
                        .foregroundStyle(.secondary)
                    Text(String(format: "%02d:%02d", Int(recorder.duration) / 60, Int(recorder.duration) % 60))
                        .font(.system(.largeTitle, design: .monospaced))
                        .contentTransition(.numericText())
                    Button {
                        if recorder.isRecording { recorder.stop() }
                        else {
                            metrics = nil
                            analysisError = nil
                            Task { await recorder.start() }
                        }
                    } label: {
                        Label(recorder.isRecording ? "Aufnahme stoppen" : "Aufnahme starten", systemImage: recorder.isRecording ? "stop.circle.fill" : "mic.circle.fill")
                            .frame(maxWidth: .infinity)
                            .padding()
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(recorder.isRecording ? .red : .teal)

                    if let url = recorder.lastURL, !recorder.isRecording {
                        Button("Aufnahme abspielen") {
                            do { player = try AVAudioPlayer(contentsOf: url); player?.play() }
                            catch { analysisError = error.localizedDescription }
                        }
                        .buttonStyle(.bordered)
                        Button("Stimme analysieren") {
                            analyzing = true
                            analysisError = nil
                            Task {
                                do { metrics = try await VoiceAnalyzer.analyze(url: url) }
                                catch { analysisError = error.localizedDescription }
                                analyzing = false
                            }
                        }
                        .buttonStyle(.borderedProminent)
                        .disabled(analyzing)
                    }
                    if analyzing { ProgressView("Analysiere …") }
                    if let metrics {
                        VStack(alignment: .leading, spacing: 12) {
                            Text("Analyseergebnis").font(.headline)
                            metric("Dauer", String(format: "%.1f Sekunden", metrics.duration))
                            metric("Durchschnittspegel", String(format: "%.1f dBFS", metrics.rmsDBFS))
                            metric("Spitzenpegel", String(format: "%.1f dBFS", metrics.peakDBFS))
                            metric("Leise Abschnitte (Schätzung)", String(format: "%.0f %%", metrics.silenceFraction * 100))
                            Text("Die Pegelwerte sind digitale Aufnahmepegel, keine kalibrierte Lautstärke. Leise Abschnitte hängen auch von Mikrofon und Umgebung ab.")
                                .font(.footnote).foregroundStyle(.secondary)
                        }
                        .padding()
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(.teal.opacity(0.09), in: RoundedRectangle(cornerRadius: 16))
                    }
                    Text("Wichtig: Aus Stimmlage, Pausen oder Lautstärke lässt sich nicht zuverlässig erkennen, ob jemand lügt. Die App erstellt keine Lügenerkennung oder psychologische Diagnose.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
                .padding()
            }
            .navigationTitle("VoiceCheck AI")
            .alert("Mikrofonzugriff erforderlich", isPresented: $recorder.permissionDenied) {
                Button("OK", role: .cancel) {}
            } message: { Text("Erlaube den Mikrofonzugriff in den iPhone-Einstellungen.") }
            .alert("Fehler", isPresented: Binding(get: { analysisError != nil || recorder.errorMessage != nil }, set: { if !$0 { analysisError = nil; recorder.errorMessage = nil } })) {
                Button("OK", role: .cancel) {}
            } message: { Text(analysisError ?? recorder.errorMessage ?? "Unbekannter Fehler") }
        }
    }

    private func metric(_ name: String, _ value: String) -> some View {
        HStack {
            Text(name)
            Spacer()
            Text(value).bold().monospacedDigit()
        }
    }
}
